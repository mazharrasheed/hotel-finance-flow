
// This file is no longer used. Modal is integrated into Sidebar.tsx.
export {};
